#ifdef  _WINDOWS_SOURCE
#ifdef  __SJDGetMeshFromRepM
#define ExportedBySJDGetMeshFromRepM     __declspec(dllexport)
#else
#define ExportedBySJDGetMeshFromRepM     __declspec(dllimport)
#endif
#else
#define ExportedBySJDGetMeshFromRepM
#endif
