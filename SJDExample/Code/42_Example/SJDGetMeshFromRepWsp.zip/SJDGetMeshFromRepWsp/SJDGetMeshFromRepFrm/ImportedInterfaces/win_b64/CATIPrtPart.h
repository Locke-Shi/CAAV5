#include "C:\DS\B22\.\MecModInterfaces\PublicInterfaces\CATIPrtPart.h"

