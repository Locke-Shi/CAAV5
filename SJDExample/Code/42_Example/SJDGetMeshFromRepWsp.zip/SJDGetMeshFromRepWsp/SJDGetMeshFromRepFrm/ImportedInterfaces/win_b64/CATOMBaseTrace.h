#include "C:\DS\B22\.\ObjectModelerBase\PublicInterfaces\CATOMBaseTrace.h"

