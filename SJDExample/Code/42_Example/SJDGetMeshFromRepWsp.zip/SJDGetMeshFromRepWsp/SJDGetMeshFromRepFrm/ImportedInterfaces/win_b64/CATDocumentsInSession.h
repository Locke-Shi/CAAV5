#include "C:\DS\B22\.\ObjectModelerBase\PublicInterfaces\CATDocumentsInSession.h"

