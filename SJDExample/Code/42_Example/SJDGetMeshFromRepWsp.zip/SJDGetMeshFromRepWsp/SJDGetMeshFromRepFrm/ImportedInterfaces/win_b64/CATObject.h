#include "C:\DS\B22\.\ObjectModelerBase\PublicInterfaces\CATObject.h"

