#include "C:\DS\B22\.\Dialog\PublicInterfaces\CATDlgResource.h"

