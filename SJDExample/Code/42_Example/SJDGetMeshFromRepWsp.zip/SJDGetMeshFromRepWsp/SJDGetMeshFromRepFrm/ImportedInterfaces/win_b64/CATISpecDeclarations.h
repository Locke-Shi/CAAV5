#include "C:\DS\B22\.\ObjectSpecsModeler\PublicInterfaces\CATISpecDeclarations.h"

