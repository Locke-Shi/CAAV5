#include "C:\DS\B22\.\CATGSMUseItf\PublicInterfaces\CATIShapeDesignWorkshopAddin.h"

