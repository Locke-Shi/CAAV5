#include "C:\DS\B22\.\DialogEngine\PublicInterfaces\CATAcquisitionFilter.h"

