#include "C:\DS\B22\.\ObjectModelerBase\PublicInterfaces\CATIStorageProperty.h"

