#ifdef  _WINDOWS_SOURCE
#ifdef  __SJDSelectObjectInMyViewerM
#define ExportedBySJDSelectObjectInMyViewerM     __declspec(dllexport)
#else
#define ExportedBySJDSelectObjectInMyViewerM     __declspec(dllimport)
#endif
#else
#define ExportedBySJDSelectObjectInMyViewerM
#endif
