#include "C:\DS\B22\.\Mathematics\PublicInterfaces\CATMathPoint2D.h"

