#include "C:\DS\B22\.\VisualizationBase\PublicInterfaces\CATSetOfObject.h"

