#include "C:\DS\B22\.\Dialog\PublicInterfaces\CATDlgLabel.h"

