#include "C:\DS\B22\.\ObjectModelerBase\PublicInterfaces\CosLinkable.h"

