#include "C:\DS\B22\.\System\PublicInterfaces\CATCreateExternalObject.h"

